package org.example;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TelaListarHospedes extends JFrame {
    private JTable tabelaHospedes;
    private DefaultTableModel tableModel;
    private HospedeDAO hospedeDAO;

    public TelaListarHospedes() {
        hospedeDAO = new HospedeDAO();


        setTitle("Listar Hóspedes");
        setSize(600, 400);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        tableModel = new DefaultTableModel();
        tableModel.addColumn("ID Hóspede");
        tableModel.addColumn("Nome");
        tableModel.addColumn("Email");
        tableModel.addColumn("Telefone");
        tableModel.addColumn("Documento");
        tableModel.addColumn("Data Nascimento");
        tableModel.addColumn("ID Quarto");
        tableModel.addColumn("Data Check-In");
        tableModel.addColumn("Data Check-Out");
        tableModel.addColumn("Status Reserva");

        tabelaHospedes = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(tabelaHospedes);

        add(scrollPane, BorderLayout.CENTER);
        JButton voltarButton = new JButton("Voltar");
        add(voltarButton, BorderLayout.SOUTH);

        voltarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new MenuPrincipal().setVisible(true);
            }
        });


        listarHospedesComReservas();
    }

    private void listarHospedesComReservas() {
        String sql = """
            SELECT h.id_hospede, h.nome, h.email, h.telefone, h.documento, h.data_nascimento,
                   r.id_quarto, r.data_check_in, r.data_check_out, r.status_reserva
            FROM hospedes h
            LEFT JOIN reservas r ON h.id_hospede = r.id_hospede
            ORDER BY h.id_hospede;
        """;

        try (Connection conexao = ConexaoBanco.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            tableModel.setRowCount(0);

            while (rs.next()) {
                Object[] row = new Object[10];
                row[0] = rs.getInt("id_hospede");
                row[1] = rs.getString("nome");
                row[2] = rs.getString("email");
                row[3] = rs.getString("telefone");
                row[4] = rs.getString("documento");
                row[5] = rs.getString("data_nascimento");
                row[6] = rs.getInt("id_quarto");
                row[7] = rs.getString("data_check_in");
                row[8] = rs.getString("data_check_out");
                row[9] = rs.getString("status_reserva");


                tableModel.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TelaListarHospedes().setVisible(true);
            }
        });
    }
}
