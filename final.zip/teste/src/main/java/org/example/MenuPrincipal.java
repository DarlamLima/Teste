package org.example;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MenuPrincipal extends JFrame {
    public MenuPrincipal() {
        setTitle("Sistema de Hospedagem");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new FlowLayout());

        JButton btnAdicionar = new JButton("Adicionar Hóspede");
        JButton btnAtualizar = new JButton("Atualizar Hóspede");
        JButton btnExcluir = new JButton("Excluir Hóspede");
        JButton btnListar = new JButton("Listar Hóspedes");

        add(btnAdicionar);
        add(btnAtualizar);
        add(btnExcluir);
        add(btnListar);

        btnAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new TelaAdicionarHospede().setVisible(true);
                dispose();
            }
        });

        btnAtualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new TelaAtualizarHospede().setVisible(true);
                dispose();
            }
        });

        btnExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new TelaExcluirHospede().setVisible(true);
                dispose();
            }
        });

        btnListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new TelaListarHospedes().setVisible(true);
                dispose();
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MenuPrincipal().setVisible(true);
            }
        });
    }
}

class TelaAdicionarHospede extends JFrame {
    private JTextField nomeField, emailField, telefoneField, documentoField, dataNascimentoField;
    private JTextField idQuartoField, dataCheckInField, dataCheckOutField, statusReservaField;
    private JButton adicionarButton;
    private HospedeDAO hospedeDAO;

    public TelaAdicionarHospede() {
        hospedeDAO = new HospedeDAO();

        setTitle("Adicionar Hóspede");
        setSize(400, 300);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new GridLayout(10, 2));

        add(new JLabel("Nome:"));
        nomeField = new JTextField();
        add(nomeField);

        add(new JLabel("Email:"));
        emailField = new JTextField();
        add(emailField);

        add(new JLabel("Telefone:"));
        telefoneField = new JTextField();
        add(telefoneField);

        add(new JLabel("Documento:"));
        documentoField = new JTextField();
        add(documentoField);

        add(new JLabel("Data Nascimento:"));
        dataNascimentoField = new JTextField();
        add(dataNascimentoField);

        add(new JLabel("ID Quarto:"));
        idQuartoField = new JTextField();
        add(idQuartoField);

        add(new JLabel("Data Check-In:"));
        dataCheckInField = new JTextField();
        add(dataCheckInField);

        add(new JLabel("Data Check-Out:"));
        dataCheckOutField = new JTextField();
        add(dataCheckOutField);

        add(new JLabel("Status Reserva:"));
        statusReservaField = new JTextField();
        add(statusReservaField);

        adicionarButton = new JButton("Adicionar");
        add(adicionarButton);

        adicionarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = nomeField.getText();
                String email = emailField.getText();
                String telefone = telefoneField.getText();
                String documento = documentoField.getText();
                String dataNascimento = dataNascimentoField.getText();
                int idQuarto = Integer.parseInt(idQuartoField.getText());
                String dataCheckIn = dataCheckInField.getText();
                String dataCheckOut = dataCheckOutField.getText();
                String statusReserva = statusReservaField.getText();

                hospedeDAO.inserirHospedeComReserva(nome, email, telefone, documento, dataNascimento, idQuarto, dataCheckIn, dataCheckOut, statusReserva);
                JOptionPane.showMessageDialog(null, "Hóspede adicionado com sucesso!");
                dispose();
                new MenuPrincipal().setVisible(true);
            }
        });
    }
}

class TelaAtualizarHospede extends JFrame {
    private JTextField idHospedeField, nomeField, emailField, telefoneField, documentoField, dataNascimentoField;
    private JTextField idQuartoField, dataCheckInField, dataCheckOutField, statusReservaField;
    private JButton atualizarButton;
    private HospedeDAO hospedeDAO;

    public TelaAtualizarHospede() {
        hospedeDAO = new HospedeDAO();

        setTitle("Atualizar Hóspede");
        setSize(400, 300);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new GridLayout(11, 2));

        add(new JLabel("ID Hóspede:"));
        idHospedeField = new JTextField();
        add(idHospedeField);

        add(new JLabel("Nome:"));
        nomeField = new JTextField();
        add(nomeField);

        add(new JLabel("Email:"));
        emailField = new JTextField();
        add(emailField);

        add(new JLabel("Telefone:"));
        telefoneField = new JTextField();
        add(telefoneField);

        add(new JLabel("Documento:"));
        documentoField = new JTextField();
        add(documentoField);

        add(new JLabel("Data Nascimento:"));
        dataNascimentoField = new JTextField();
        add(dataNascimentoField);

        add(new JLabel("ID Quarto:"));
        idQuartoField = new JTextField();
        add(idQuartoField);

        add(new JLabel("Data Check-In:"));
        dataCheckInField = new JTextField();
        add(dataCheckInField);

        add(new JLabel("Data Check-Out:"));
        dataCheckOutField = new JTextField();
        add(dataCheckOutField);

        add(new JLabel("Status Reserva:"));
        statusReservaField = new JTextField();
        add(statusReservaField);

        atualizarButton = new JButton("Atualizar");
        add(atualizarButton);

        atualizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int idHospede = Integer.parseInt(idHospedeField.getText());
                String nome = nomeField.getText();
                String email = emailField.getText();
                String telefone = telefoneField.getText();
                String documento = documentoField.getText();
                String dataNascimento = dataNascimentoField.getText();
                int idQuarto = Integer.parseInt(idQuartoField.getText());
                String dataCheckIn = dataCheckInField.getText();
                String dataCheckOut = dataCheckOutField.getText();
                String statusReserva = statusReservaField.getText();

                hospedeDAO.atualizarHospedeEReserva(idHospede, nome, email, telefone, documento, dataNascimento, idQuarto, dataCheckIn, dataCheckOut, statusReserva);
                JOptionPane.showMessageDialog(null, "Hóspede atualizado com sucesso!");
                dispose();
                new MenuPrincipal().setVisible(true);
            }
        });
    }
}

class TelaExcluirHospede extends JFrame {
    private JTextField idHospedeField;
    private JButton excluirButton;
    private HospedeDAO hospedeDAO;

    public TelaExcluirHospede() {
        hospedeDAO = new HospedeDAO();

        setTitle("Excluir Hóspede");
        setSize(300, 200);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new GridLayout(2, 2));

        add(new JLabel("ID Hóspede:"));
        idHospedeField = new JTextField();
        add(idHospedeField);

        excluirButton = new JButton("Excluir");
        add(excluirButton);

        excluirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int idHospede = Integer.parseInt(idHospedeField.getText());
                hospedeDAO.excluirHospedeEReservas(idHospede);
                JOptionPane.showMessageDialog(null, "Hóspede excluído com sucesso!");
                dispose();
                new MenuPrincipal().setVisible(true);
            }
        });
    }
}
