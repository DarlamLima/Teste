package org.example;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class HospedeDAO {
    public void inserirHospedeComReserva(String nome, String email, String telefone, String documento, String dataNascimento, int idQuarto, String dataCheckIn, String dataCheckOut, String statusReserva) {
        String sqlHospede = "INSERT INTO hospedes (nome, email, telefone, documento, data_nascimento) VALUES (?, ?, ?, ?, ?)";
        String sqlReserva = "INSERT INTO reservas (id_hospede, id_quarto, data_check_in, data_check_out, status_reserva) VALUES (?, ?, ?, ?, ?)";

        try (Connection conexao = ConexaoBanco.conectar();
             PreparedStatement stmtHospede = conexao.prepareStatement(sqlHospede, Statement.RETURN_GENERATED_KEYS);
             PreparedStatement stmtReserva = conexao.prepareStatement(sqlReserva)) {

            stmtHospede.setString(1, nome);
            stmtHospede.setString(2, email);
            stmtHospede.setString(3, telefone);
            stmtHospede.setString(4, documento);
            stmtHospede.setString(5, dataNascimento);
            stmtHospede.executeUpdate();


            ResultSet rs = stmtHospede.getGeneratedKeys();
            if (rs.next()) {
                int idHospede = rs.getInt(1);


                stmtReserva.setInt(1, idHospede);
                stmtReserva.setInt(2, idQuarto);
                stmtReserva.setString(3, dataCheckIn);
                stmtReserva.setString(4, dataCheckOut);
                stmtReserva.setString(5, statusReserva);
                stmtReserva.executeUpdate();

                System.out.println("Hóspede e reserva inseridos com sucesso!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void listarHospedesComReservas(JTextArea resultadoTextArea) {
        String sql = """
        SELECT h.id_hospede, h.nome, h.email, h.telefone, h.documento, h.data_nascimento,
               r.id_reserva, r.data_check_in, r.data_check_out, r.status_reserva,
               q.id_quarto, q.tipo_quarto, q.preco
        FROM hospedes h
        LEFT JOIN reservas r ON h.id_hospede = r.id_hospede
        LEFT JOIN quartos q ON r.id_quarto = q.id_quarto
        ORDER BY h.id_hospede;
    """;

        try (Connection conexao = ConexaoBanco.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                System.out.println("\n--- Hóspede ---");
                System.out.println("ID: " + rs.getInt("id_hospede"));
                System.out.println("Nome: " + rs.getString("nome"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Telefone: " + rs.getString("telefone"));
                System.out.println("Documento: " + rs.getString("documento"));
                System.out.println("Data de Nascimento: " + rs.getString("data_nascimento"));

                System.out.println("\n--- Reserva ---");
                int idReserva = rs.getInt("id_reserva");
                if (idReserva > 0) {
                    System.out.println("ID Reserva: " + idReserva);
                    System.out.println("Data Check-In: " + rs.getString("data_check_in"));
                    System.out.println("Data Check-Out: " + rs.getString("data_check_out"));
                    System.out.println("Status da Reserva: " + rs.getString("status_reserva"));

                    System.out.println("\n--- Quarto ---");
                    System.out.println("ID Quarto: " + rs.getInt("id_quarto"));
                    System.out.println("Tipo: " + rs.getString("tipo_quarto"));
                    System.out.println("Preço: " + rs.getDouble("preco"));
                } else {
                    System.out.println("Nenhuma reserva associada.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void atualizarHospedeEReserva(int idHospede, String novoNome, String novoEmail, String novoTelefone, String novoDocumento, String novaDataNascimento,
                                         int novoIdQuarto, String novaDataCheckIn, String novaDataCheckOut, String novoStatusReserva) {
        String sqlHospede = "UPDATE hospedes SET nome = ?, email = ?, telefone = ?, documento = ?, data_nascimento = ? WHERE id_hospede = ?";
        String sqlReserva = "UPDATE reservas SET id_quarto = ?, data_check_in = ?, data_check_out = ?, status_reserva = ? WHERE id_hospede = ?";

        try (Connection conexao = ConexaoBanco.conectar();
             PreparedStatement stmtHospede = conexao.prepareStatement(sqlHospede);
             PreparedStatement stmtReserva = conexao.prepareStatement(sqlReserva)) {


            stmtHospede.setString(1, novoNome);
            stmtHospede.setString(2, novoEmail);
            stmtHospede.setString(3, novoTelefone);
            stmtHospede.setString(4, novoDocumento);
            stmtHospede.setString(5, novaDataNascimento);
            stmtHospede.setInt(6, idHospede);
            stmtHospede.executeUpdate();

            stmtReserva.setInt(1, novoIdQuarto);
            stmtReserva.setString(2, novaDataCheckIn);
            stmtReserva.setString(3, novaDataCheckOut);
            stmtReserva.setString(4, novoStatusReserva);
            stmtReserva.setInt(5, idHospede);
            stmtReserva.executeUpdate();

            System.out.println("Dados do hóspede e reserva atualizados com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void excluirHospedeEReservas(int idHospede) {
        String sqlReservas = "DELETE FROM reservas WHERE id_hospede = ?";
        String sqlHospede = "DELETE FROM hospedes WHERE id_hospede = ?";

        try (Connection conexao = ConexaoBanco.conectar();
             PreparedStatement stmtReservas = conexao.prepareStatement(sqlReservas);
             PreparedStatement stmtHospede = conexao.prepareStatement(sqlHospede)) {


            stmtReservas.setInt(1, idHospede);
            stmtReservas.executeUpdate();


            stmtHospede.setInt(1, idHospede);
            stmtHospede.executeUpdate();

            System.out.println("Hóspede e reservas associadas excluídos com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



}

