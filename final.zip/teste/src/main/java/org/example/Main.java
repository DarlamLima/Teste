package org.example;

import javax.swing.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        HospedeDAO dao = new HospedeDAO();
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("\n=== Sistema de Gerenciamento de Hóspedes ===");
            System.out.println("1. Inserir Hóspede");
            System.out.println("2. Listar Hóspedes");
            System.out.println("3. Atualizar Hóspede");
            System.out.println("4. Excluir Hóspede");
            System.out.println("5. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    System.out.println("\n--- Inserir Hóspede com Reserva ---");
                    System.out.print("Nome: ");
                    String nome = scanner.nextLine();
                    System.out.print("Email: ");
                    String email = scanner.nextLine();
                    System.out.print("Telefone: ");
                    String telefone = scanner.nextLine();
                    System.out.print("Documento: ");
                    String documento = scanner.nextLine();
                    System.out.print("Data de Nascimento (AAAA-MM-DD): ");
                    String dataNascimento = scanner.nextLine();
                    System.out.print("ID do Quarto: ");
                    int idQuarto = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Data de Check-In (AAAA-MM-DD): ");
                    String dataCheckIn = scanner.nextLine();
                    System.out.print("Data de Check-Out (AAAA-MM-DD): ");
                    String dataCheckOut = scanner.nextLine();
                    System.out.print("Status da Reserva (ex: ativo, cancelado): ");
                    String statusReserva = scanner.nextLine();

                    dao.inserirHospedeComReserva(nome, email, telefone, documento, dataNascimento, idQuarto, dataCheckIn, dataCheckOut, statusReserva);
                    break;
                case 2:
                    System.out.println("\n--- Listar Hóspedes e Reservas ---");
                    JTextArea resultadoTextArea = null;
                    dao.listarHospedesComReservas(resultadoTextArea);
                    break;

                case 3:
                    System.out.println("\n--- Atualizar Hóspede e Reserva ---");
                    System.out.print("ID do Hóspede a ser atualizado: ");
                    int idHospede = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Novo Nome: ");
                    String novoNome = scanner.nextLine();
                    System.out.print("Novo Email: ");
                    String novoEmail = scanner.nextLine();
                    System.out.print("Novo Telefone: ");
                    String novoTelefone = scanner.nextLine();
                    System.out.print("Novo Documento: ");
                    String novoDocumento = scanner.nextLine();
                    System.out.print("Nova Data de Nascimento (AAAA-MM-DD): ");
                    String novaDataNascimento = scanner.nextLine();
                    System.out.print("Novo ID do Quarto: ");
                    int novoIdQuarto = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Nova Data de Check-In (AAAA-MM-DD): ");
                    String novaDataCheckIn = scanner.nextLine();
                    System.out.print("Nova Data de Check-Out (AAAA-MM-DD): ");
                    String novaDataCheckOut = scanner.nextLine();
                    System.out.print("Novo Status da Reserva (Confirmada, Cancelada, Ocupada): ");
                    String novoStatusReserva = scanner.nextLine();

                    dao.atualizarHospedeEReserva(idHospede, novoNome, novoEmail, novoTelefone, novoDocumento, novaDataNascimento,
                            novoIdQuarto, novaDataCheckIn, novaDataCheckOut, novoStatusReserva);
                    break;

                case 4:
                    System.out.println("\n--- Excluir Hóspede e Reservas ---");
                    System.out.print("ID do Hóspede a ser excluído: ");
                    int idHospedeExcluir = scanner.nextInt();
                    scanner.nextLine();

                    dao.excluirHospedeEReservas(idHospedeExcluir);
                    break;


                default:
                    System.out.println("\nOpção inválida. Tente novamente.");
            }
        } while (opcao != 5);

        scanner.close();
    }
}
